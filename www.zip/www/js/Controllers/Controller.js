angular
    .module('starter.controllers')
    .controller('AppCtrl', function($scope) {
        //  $state.go('app.buildingList');
        //   $scope.$on('$ionicView.beforeEnter', function (event, vionicSideMenuDelegate,iewData) {
        //  viewData.enableBack = true;
        //}); 
    alert('controller');
      
    });