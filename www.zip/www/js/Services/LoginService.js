angular
    .module('starter')
    .factory('bigLiZtLoginFactory', function($http,$localStorage,baseUrlFactory) {
        var urlBase = baseUrlFactory.urlBase;
       // alert('tesing service login');
        return {
            //Login
            login: function(loginData) {
                return $http({
                    method: 'POST',
                    url: urlBase + 'users/login',
                    data: loginData,
                })
            },

          
            getTenantByUserId: function(userId) {
                return $http({
                    method: 'GET',
                    url: urlBase + 'tenants/getTenantByUserId?userId=' + userId,
                    headers: {
                        'x-access-token': $localStorage.token
                    }
                })
            },
                getLandLordByUserId: function(userId) {
                return $http({
                    method: 'GET',
                    url: urlBase + 'landlords/getByUserId?userId=' + userId,
                    headers: {
                        'x-access-token': $localStorage.token
                    }
                })
            },
            signUp: function(registerdata) {

                       return $http({
                         method: 'POST',
                         url: urlBase + 'users/add',
                         data: registerdata,
                       })
                     },
           
           
        }

    });