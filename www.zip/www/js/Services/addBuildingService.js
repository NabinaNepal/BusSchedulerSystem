angular
    .module('starter')
    .factory('savePropertyFactory', function($http,$localStorage,baseUrlFactory) {
      var urlBase = baseUrlFactory.urlBase;
        return {
            
            saveProperty: function(landlord) {
                return $http({
                    method: 'POST',
                    url: urlBase + 'buildings/add',
                    headers: {
                        'x-access-token': $localStorage.token
                    },
                    data: landlord

                })
            },
               getLandlordById: function() {
                return $http({
                    method: 'GET',
                    url: urlBase + 'landlords/getbyid?landlordId=' + $localStorage.landLordId,
                    headers: {
                        'x-access-token': $localStorage.token
                    }
                })
            },
              getBuildingById: function(buildingId) {
                return $http({
                    method: 'GET',
                    url: urlBase + 'buildings/getbyid?buildingId=' + buildingId,
                    headers: {
                        'x-access-token': $localStorage.token
                    }
                })
            },


        }

    });