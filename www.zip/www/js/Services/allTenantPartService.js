angular
    .module('starter')
    .factory('allTenantPartFactory', function($http, $localStorage,baseUrlFactory) {
        var urlBase = baseUrlFactory.urlBase;
        return {

            saveTenant: function(tenant) {
                return $http({
                    method: 'POST',
                    url: urlBase + 'tenants/add',
                    headers: {
                        'x-access-token': $localStorage.token
                    },
                    data: tenant

                })
            },
            tenantListByBuildingId: function() {

                return $http({
                    method: 'GET',
                    url: urlBase + 'tenants/getByBuildingId?buildingId=' + $localStorage.buildingId,
                    headers: {
                        'x-access-token': $localStorage.token
                    },
                })

            },
             tenantFaultsLists: function() {

                return $http({
                    method: 'GET',
                    url: urlBase + 'faults/getbylandlordId?landlordId='+$localStorage.landlordId,
                    //http://54.191.65.126:8082/faults/getbylandlordId?landlordId=57ac2a9c4d86619d09bfa3f9
                    headers: {
                        'x-access-token': $localStorage.token
                    },
                })

            },
              getTenantreview: function(tenantId) {
                return $http({
                    method: 'GET',
                    url: urlBase + 'tenantreviews/getByTenantId',
                    headers: {
                        'x-access-token': $localStorage.token
                    },
                    params: {
                        "tenantId": tenantId,
                        "landlordId": $localStorage.landlordId,
                        "buildingId":$localStorage.buildingId
                    },

                })

            },
             rateTenant: function(tenantInfo) {

                return $http({
                    method: 'POST',
                    url: urlBase + 'tenantreviews/add',
                    headers: {
                        'x-access-token': $localStorage.token
                    },
                    data: tenantInfo
                })

            },
              updateRate: function(tenantInfo) {
                return $http({
                    method: 'POST',
                    url: urlBase + 'tenantreviews/update',
                    headers: {
                        'x-access-token': $localStorage.token
                    },
                    data: tenantInfo
                })

            },
            tenantProfileByLandlordandSSN: function(ssn) {

                return $http({
                    method: 'GET',
                    url: urlBase + 'tenants/getTenantProfileByLandlord',
                    headers: {
                        'x-access-token': $localStorage.token
                    },
                    params: {
                        "ssnTin":ssn,
                        "landlordId": $localStorage.landlordId,
                        "buildingId":$localStorage.buildingId
                       
                    },
                })

            },
              suggestCategory: function(fault) {

                return $http({
                    method: 'POST',
                    url: urlBase + 'faults/add',
                    headers: {
                        'x-access-token': $localStorage.token
                    },
                    // params: {
                    //    "fault" : fault,
                    //    "landlordId" : "57b9719f017ae2c9babf02a9"
                    // },
                    data: fault
                })

            },
            tenantInfoDelete: function(deleteTenantId) {

                return $http({
                    method: 'POST',
                    url: urlBase + 'tenants/delete?tenantId=' + deleteTenantId,
                    headers: {
                        'x-access-token': $localStorage.token
                    }

                })
            },
            getRentInfo: function() {

                return $http({
                    method: 'GET',
                    url: urlBase + 'tenants/getRentDate?tenantId=' + $localStorage.tenantId,
                    headers: {
                        'x-access-token': $localStorage.token
                    }

                })
            },
            sendRentInfo: function(rentInfo) {

                return $http({
                    method: 'POST',
                    url: urlBase + 'tenants/updateRentDate',
                    headers: {
                        'x-access-token': $localStorage.token
                    },
                    data: rentInfo

                })
            },
            addTenantNote: function(noteInfo) {

                return $http({
                    method: 'POST',
                    url: urlBase + 'tenants/addnote',
                    headers: {
                        'x-access-token': $localStorage.token
                    },
                    data: noteInfo

                })
            },
            getNoteList: function(tenantId) {

                return $http({
                    method: 'GET',
                    url: urlBase + 'tenants/getById?tenantId=' + tenantId,
                    headers: {
                        'x-access-token': $localStorage.token
                    }

                })
            },
            addPaymentDateNote: function(paymentData) {

                return $http({
                    method: 'POST',
                    url: urlBase + 'tenants/addPaymentNote',
                    headers: {
                        'x-access-token': $localStorage.token
                    },
                    data: paymentData
                })
            },
            editPaymentDateNote: function(paymentData) {

                return $http({
                    method: 'POST',
                    url: urlBase + 'tenants/updatePaymentNote',
                    headers: {
                        'x-access-token': $localStorage.token
                    },
                    data: paymentData
                })
            },
            getExistingTenantByBuildingUnit: function(getData) {

                return $http({
                    method: 'GET',
                    url: urlBase + 'tenants/getTenantByUnitAndBuildingId?buildingId='+getData.buildingId+'&unit='+getData.unit,
                    headers: {
                        'x-access-token': $localStorage.token
                    }
                })
            },
            getTenantByIds: function(idList) {

                return $http({
                    method: 'POST',
                    url: urlBase + 'tenants/getTenantsByIds',
                    headers: {
                        'x-access-token': $localStorage.token
                    },
                    data: idList
                })
            },
            deleteTenantByIds: function(idList) {

                return $http({
                    method: 'POST',
                    url: urlBase + 'tenants/deleteTenantsByIds',
                    headers: {
                        'x-access-token': $localStorage.token
                    },
                    data: idList
                })
            },
            postTenantReview: function(postReviewData) {

                return $http({
                    method: 'POST',
                    url: urlBase + 'tenants/postTenantReview',
                    headers: {
                        'x-access-token': $localStorage.token
                    },
                    data: postReviewData
                })
            },
             postTenantReview: function(tenatPrevData) {

                return $http({
                    method: 'POST',
                    url: urlBase + 'tenantFile/addPreviousLandlord',
                    headers: {
                        'x-access-token': $localStorage.token
                    },
                    data: tenatPrevData
                })
            },



        }
    });