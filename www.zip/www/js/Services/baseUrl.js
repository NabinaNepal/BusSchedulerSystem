angular
  .module('starter')
  .factory('baseUrlFactory', function ($http, $localStorage) {

    //var urlBase = 'http://appserver2.spiralogics.com:8095/';
    //var urlBase='http://ec2-52-88-149-175.us-west-2.compute.amazonaws.com:8085/';
    //var urlBase = 'http://54.191.65.126:8085/';
    var urlBase = 'http://dev.spiralogics.com:8085/';
   
    return {
      urlBase: urlBase
    }
  });
