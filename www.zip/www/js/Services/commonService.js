angular
    .module('starter')
    .factory('commonFactory', function($ionicLoading, $timeout, $ionicPopup) {
        //loder
        // alert('tesing service common');
        var imageBaseUrl = "http://dev.spiralogics.com:8085/static/images/";
        var uploadImageUrl = "http://dev.spiralogics.com:8085/file/upload";

        var showLoading = function() {
            $ionicLoading.show({
                template: "<i class='icon ion-load-c'></i>"
            });
        };

        var hideLoading = function() {
            $ionicLoading.hide();
        };

        //PopupMessage
        var showPopup = function(title, message) {
            var alertPopup = $ionicPopup.show({
                title: title,
                template: message
            });
            $timeout(function() {
                alertPopup.close(); //close the popup after 3 seconds for some reason
            }, 2000);
        }

        var showImageLoading = function() {
            $ionicLoading.show({
                template: "<i class='ion-ios-upload-outline'></i> Images Uploading..."
            });
        };

        var hideImageLoading = function() {
            $ionicLoading.hide();
        };
        return {
            showLoader: showLoading,
            hideLoader: hideLoading,
            showPopup: showPopup,
            imageBaseUrl: imageBaseUrl,
            uploadImageUrl: uploadImageUrl,
            showImageLoading: showImageLoading,
            hideImageLoading: hideImageLoading
        }

    });