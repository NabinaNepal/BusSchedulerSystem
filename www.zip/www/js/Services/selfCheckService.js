angular
    .module('starter')
    .factory('bigLiZtselfcheckFactory', function($http,$localStorage,baseUrlFactory) {
         var urlBase = baseUrlFactory.urlBase;
        return {
            
            selfCheck: function(ssn) {
                return $http({
                    method: 'GET',
                    url: urlBase + 'tenants/getTenantSelfCheck?ssnTin='+ssn,
                    headers: { 'x-access-token': $localStorage.token }
                })
            },
            getProfile: function(ssn) {
                return $http({
                    method: 'GET',
                    url: urlBase + 'tenants/getProfile?ssnTin='+ssn,
                    headers: { 'x-access-token': $localStorage.token }
                })
            },
            checkTenant: function(ssnData) {
                return $http({
                    method: 'POST',
                    url: urlBase + 'tenants/checkForValidName',
                    headers: { 'x-access-token': $localStorage.token },
                    data:ssnData
                })
            },
        }

    });