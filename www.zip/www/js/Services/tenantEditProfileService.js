angular
    .module('starter')
    .factory('tenantProfileFactory', function($http, $localStorage,baseUrlFactory) {
        var urlBase = baseUrlFactory.urlBase;
        return {

            getTenantDetailProfile: function() {
                return $http({
                    method: 'GET',
                    url: urlBase + 'users/getByEmail?email=' + $localStorage.email,
                    headers: {
                        'x-access-token': $localStorage.token
                    }
                })
            },
            updateTenantUserProfile: function(updatedData) {
                return $http({
                    method: 'POST',
                    url: urlBase + 'landlords/update',
                    data: updatedData,
                    headers: {
                        'x-access-token': $localStorage.token
                    }
                })
            },
             changePassword: function(changepasswordData) {
                return $http({
                    method: 'POST',
                    url: urlBase + 'users/changepassword',
                    headers: {
                        'x-access-token': $localStorage.token
                    },
                    data: changepasswordData,
                })
            },
            viewInfoTenant: function(ssn) {
                return $http({
                    method: 'GET',
                    url: urlBase + 'tenants/getTenantSelfCheck?ssnTin='+ssn,
                    headers: { 'x-access-token': $localStorage.token }
                })
            },
            addemployement: function(employement) {
                return $http({
                    method: 'POST',
                    url: urlBase + 'tenantFile/addEmployement',
                    headers: { 'x-access-token': $localStorage.token },
                    data:employement
                })
            },
            addPersonalInformation: function(addPersonalInformation) {
                return $http({
                    method: 'POST',
                    url: urlBase + 'tenantFile/addPersonalInformation',
                    headers: { 'x-access-token': $localStorage.token },
                    data:addPersonalInformation
                })
            },
            addPreviousLandlord: function(addPreviousLandlord) {
                return $http({
                    method: 'POST',
                    url: urlBase + 'tenantFile/addPreviousLandlord',
                    headers: { 'x-access-token': $localStorage.token },
                    data:addPreviousLandlord
                })
            }

        }

    });