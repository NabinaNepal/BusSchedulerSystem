angular
    .module('starter')
    .factory('userPofileFactory', function($http, $localStorage,baseUrlFactory) {
        var urlBase = baseUrlFactory.urlBase;
        return {

            getLoginUserDetailProfile: function() {
                return $http({
                    method: 'GET',
                    url: urlBase + 'users/getByEmail?email=' + $localStorage.email,
                    headers: {
                        'x-access-token': $localStorage.token
                    }
                })
            },
            updateLoginUserProfile: function(updatedData) {
                return $http({
                    method: 'POST',
                    url: urlBase + 'landlords/update',
                    data: updatedData,
                    headers: {
                        'x-access-token': $localStorage.token
                    }
                })
            },
             changePassword: function(changepasswordData) {
                return $http({
                    method: 'POST',
                    url: urlBase + 'users/changepassword',
                    headers: {
                        'x-access-token': $localStorage.token
                    },
                    data: changepasswordData,
                })
            },


        }

    });