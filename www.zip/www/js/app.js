// Ionic Starter App
// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
angular.module('starter', ['ionic', 'starter.controllers', 'ngCordova', 'toastr', 'ngStorage'])

.run(function($ionicPlatform, $state) {
        $ionicPlatform.ready(function() {   
            // window.addEventListener("deviceready", function()
            //                                {
            //                                 if(window.localstorage.getItem("username")!== null && window.localstorage.getItem("password")!== null){
            //                                 $state.go('landlordapp.landLordHomeLanding');
            //                                 }
            //                                 else
            //                                     $state.go('landing.landingView');

            //                                 }, false);         
            if (window.cordova && window.cordova.plugins.Keyboard) {
                // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
                // for form inputs)
                cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);

                // Don't remove this line unless you know what you are doing. It stops the viewport
                // from snapping when text inputs are focused. Ionic handles this internally for
                // a much nicer keyboard experience.
                cordova.plugins.Keyboard.disableScroll(true);
            }
            if (window.StatusBar) {
                StatusBar.styleDefault();
            }
        });
        $ionicPlatform.ready(function() {

            // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
            // for form inputs)
            if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
                //alert('testtteees');
                cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
                cordova.plugins.Keyboard.disableScroll(true);
                // cordova.plugins.Keyboard.close();           
            }
            // debugger;
            window.addEventListener('native.keyboardshow', function() {
                //alert('add');
                document.body.classList.add('keyboard-open');
            });
            window.addEventListener('native.keyboardhide', function() {
                //alert('remove');
                document.body.classList.remove('keyboard-open');
            });
            if (window.StatusBar) {
                // org.apache.cordova.statusbar required
                StatusBar.styleDefault();
            }

        });
    })
    .config(function($stateProvider, $urlRouterProvider, $ionicConfigProvider) {
        $ionicConfigProvider.views.swipeBackEnabled(false);


        $stateProvider
            .state('landing', {
                url: '/landing',
                abstract: true,
                templateUrl: 'templates/Common/LandingViewMenu.html',
                controller: 'testSliderCtrl'
            })

        .state('landing.landingView', {

                url: '/landingView',
                views: {
                    'landingMenu': {
                        templateUrl: 'templates/Common/LandingView.html',
                        controller: 'landingViewCtrl'
                    }
                }
            })
            .state('landing.tenantSecondLandingView', {
                cache: false,
                url: '/tenantSecondLandingView',
                views: {
                    'landingMenu': {
                        templateUrl: 'templates/Common/tenantSecondLandingView.html',
                        controller: 'tenantsecondlandingviewCtrl'
                    }
                }
            })

        .state('landing.buslistView', {
            cache: false,
            url: '/buslist',
            views: {
                'landingMenu': {
                    templateUrl: 'templates/Common/buslist.html',
                    controller: 'buslistctrl'
                }
            }
        })

        // .state('landing.tenantregistration', {
        //         cache: false,
        //         url: '/tenantregistration',
        //         views: {
        //             'landingMenu': {
        //                 templateUrl: 'templates/tenantTestPart/tenantRegistration/tenantRegistration.html',
        //                 controller: 'tenantRegistrationCtrl'
        //             }
        //         }
        //     })
       

        //     .state('landing.tenantaddphoto', {
        //         cache: false,
        //         url: '/tenantaddphoto',
        //         views: {
        //             'landingMenu': {
        //                 templateUrl: 'templates/tenantTestPart/tenantRegistration/tenantAddPhoto.html',
        //                 controller: 'tenantaddphotoCtrl'
        //             }
        //         }
        //     })
        //     .state('landing.landlordLandingPage', {
        //         cache: false,
        //         url: '/landlordLanding',
        //         views: {
        //             'landingMenu': {
        //                 templateUrl: 'templates/landlordPart/landlordLandingPage.html',
        //                 controller: 'landlordlandingviewCtrl'
        //             }
        //         }
        //     })

        // .state('landing.landlordLogin', {
        //         cache: false,
        //         url: '/landlordLogin',
        //         views: {
        //             'landingMenu': {
        //                 templateUrl: 'templates/landlordPart/landlordLogin/landlordLogin.html',
        //                 controller: 'landlordloginCtrl'
        //             }
        //         }
        //     })
        //     .state('landing.landlordsignup', {
        //         cache: false,
        //         url: '/landlordsignup',
        //         views: {
        //             'landingMenu': {
        //                 templateUrl: 'templates/landlordPart/landlordSignup/signup.html',
        //                 controller: 'signupCtrl'
        //             }
        //         }
        //     })
        //     .state('landing.landlordsignupaddphoto', {
        //         cache: false,
        //         url: '/landlordsignupaddphoto',
        //         views: {
        //             'landingMenu': {
        //                 templateUrl: 'templates/landlordPart/landlordSignup/addSignUpPhoto.html',
        //                 controller: 'addsignupphotoCtrl'
        //             }
        //         }
        //     })
        //     .state('landing.landlordverfication', {
        //         cache: false,
        //         url: '/landlordverfication',
        //         views: {
        //             'landingMenu': {
        //                 templateUrl: 'templates/landlordPart/landLordVerification/landlordVerification.html',
        //                 controller: 'landlordVerificationCtrl'
        //             }
        //         }
        //     })

        // $stateProvider
        //     .state('app', {
        //         url: '/app',
        //         abstract: true,
        //         templateUrl: 'templates/Common/LandingMenu.html',
        //         controller: 'testSliderCtrl'
        //     })
        //     .state('app.tenanthome', {
        //         cache: false,
        //         url: '/tenanthome',
        //         views: {
        //             'menuContent': {
        //                 templateUrl: 'templates/tenantTestPart/tenantHome/home.html',
        //                 controller: 'tenanthomeCtrl'
        //             }
        //         }
        //     })
        //     // .state('app.tenantlogin', {
        //     //     cache: false,
        //     //     url: '/tenantlogin',
        //     //     views: {
        //     //         'menuContent': {
        //     //             templateUrl: 'templates/tenantTestPart/tenantLogin/login.html',
        //     //             controller: 'tenantloginCtrl'
        //     //         }
        //     //     }
        //     // })
        //     .state('app.tenantfiledetail', {
        //             cache: false,
        //             url: '/tenantfiledetail',
        //             views: {
        //                 'menuContent': {
        //                     templateUrl: 'templates/tenantTestPart/tenantRegistration/tenantFileDetail.html',
        //                     controller: 'tenantfiledetailCtrl'
        //                 }
        //             }
        //         })
        //     .state('app.employmentinformation', {
        //             cache: false,
        //             url: '/employmentinformation',
        //             views: {
        //                 'menuContent': {
        //                     templateUrl: 'templates/tenantTestPart/tenantFileDetailInfo/employmentInformation.html',
        //                     controller: 'employmentinformationCtrl'
        //                 }
        //             }
        //         })
        //     .state('app.previouslandlord', {
        //             cache: false,
        //             url: '/previouslandlord',
        //             views: {
        //                 'menuContent': {
        //                     templateUrl: 'templates/tenantTestPart/tenantFileDetailInfo/previousLandlord.html',
        //                     controller: 'previouslandlordCtrl'
        //                 }
        //             }
        //         })
        //     .state('app.personalinformation', {
        //             cache: false,
        //             url: '/personalinformation',
        //             views: {
        //                 'menuContent': {
        //                     templateUrl: 'templates/tenantTestPart/tenantFileDetailInfo/personalInformation.html',
        //                     controller: 'personalinformationCtrl'
        //                 }
        //             }
        //         })
        //     .state('app.tenantfullprofile', {
        //         cache: false,
        //         url: '/tenantfullprofile',
        //         views: {
        //             'menuContent': {
        //                 templateUrl: 'templates/tenantTestPart/tenantFullProfile/tenantFullProfile.html',
        //                 controller: 'tenantfullprofileCtrl'
        //             }
        //         }
        //     })
        //     .state('app.tenantfile', {
        //         cache: false,
        //         url: '/tenantfile',
        //         views: {
        //             'menuContent': {
        //                 templateUrl: 'templates/tenantTestPart/tenantFile/tenantFile.html',
        //                 controller: 'tenantfileCtrl'
        //             }
        //         }
        //     })
        //     .state('app.tenantselfcheck', {
        //         cache: false,
        //         url: '/tenantselfcheck',
        //         views: {
        //             'menuContent': {
        //                 templateUrl: 'templates/tenantTestPart/tenantSelfCheck/tenantSelfCheck.html',
        //                 controller: 'tenantselfcheckCtrl'
        //             }
        //         }
        //     })

        // .state('app.selfCheckProfile', {
        //         cache: false,
        //         url: '/selfCheckProfile',
        //         views: {
        //             'menuContent': {
        //                 templateUrl: 'templates/tenantTestPart/tenantSelfCheck/tenantSelfCheckProfile.html',
        //                 controller: 'tenantSelfCheckProfileCtrl'
        //             }
        //         }
        //     })
        //     .state('app.viewtenantinfo', {
        //         cache: false,
        //         url: '/viewtenantinfo',
        //         views: {
        //             'menuContent': {
        //                 templateUrl: 'templates/tenantTestPart/tenantViewAndEdit/viewInfo.html',
        //                 controller: 'viewTenantInfoCtrl'
        //             }
        //         }
        //     })




        // $stateProvider
        //     .state('landlordapp', {
        //         url: '/landlordapp',
        //         abstract: true,
        //         templateUrl: 'templates/landlordPart/menu/menu.html',
        //         controller: 'landlordMenuCtrl'
        //     })
        //     // .state('landlordapp.landlordsignup', {
        //     //     cache: false,
        //     //     url: '/landlordsignup',
        //     //     views: {
        //     //         'landlordMenuContent': {
        //     //             templateUrl: 'templates/landlordPart/landlordSignup/signup.html',
        //     //             controller: 'signupCtrl'
        //     //         }
        //     //     }
        //     // })
        //     .state('landlordapp.signupverification', {
        //         cache: false,
        //         url: '/signupverification',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/landLordVerification/signUpVerification.html',
        //                 controller: 'signUpVerificationCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.landlordverfication', {
        //         cache: false,
        //         url: '/landlordverfication',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/landLordVerification/landlordVerification.html',
        //                 controller: 'landlordVerificationCtrl'
        //             }
        //         }
        //     })
        //      .state('landlordapp.menuaddbuilding', {
        //         cache: false,
        //         url: '/landlordverfication',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/menu/menuAddBuilding.html',
        //                 controller: 'menuaddBuildingNotateCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.codeVerified', {
        //         cache: false,
        //         url: '/codeVerified',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/landLordVerification/codeVerified.html',
        //                 controller: 'codeVerifiedCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.codenotverified', {
        //         cache: false,
        //         url: '/codenotverified',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/landLordVerification/codeNotVerified.html',
        //                 controller: 'codeNotVerifiedCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.inputproperty', {
        //         cache: false,
        //         url: '/inputproperty',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/inputProperty/inputProperty.html',
        //                 controller: 'inputPropertCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.landlordinputproperty', {
        //         cache: false,
        //         url: '/landlordinputproperty',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/inputProperty/continueinputproperty.html',
        //                 controller: 'continueinputpropertyCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.landlordHome', {
        //         cache: false,
        //         url: '/landlordHome',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/Home/landlordHome.html',
        //                 controller: 'landlordHomeCtrl'
        //             }
        //         }
        //     })
        //      .state('landlordapp.addbuildingaddremovetenant', {
        //         cache: false,
        //         url: '/addbuildingaddremovetenant',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/Home/addBuildingAddRemoveTenant.html',
        //                 controller: 'addBuildingAddRemoveTenantCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.winacruise', {
        //         cache: false,
        //         url: '/winacruise',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/LandLordHome/winACruise.html',
        //                 controller: 'winACruiseCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.readacrazystories', {
        //         cache: false,
        //         url: '/readacrazystories',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/LandLordHome/crazyTenantStories.html',
        //                 controller: 'crazyTenantStoriesCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.manageexistingtenant', {
        //         cache: false,
        //         url: '/manageexistingtenant',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/LandLordHome/manageExistingTenant.html',
        //                 controller: 'manageExistingTenantCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.invitenewtenant', {
        //         cache: false,
        //         url: '/invitenewtenant',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/inviteTenant/inviteNewTenant.html',
        //                 controller: 'inviteNewTenantCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.invitepotentialtenant', {
        //         cache: false,
        //         url: '/invitepotentialtenant',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/inviteTenant/invitePotentialTenant.html',
        //                 controller: 'invitePotentialTenantCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.editaddremovetenant', {
        //         cache: false,
        //         url: '/editaddremovetenant',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/manageExistingTenant/editAddRemoveTenant.html',
        //                 controller: 'editAddRemoveTenantCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.lookupatenant', {
        //         cache: false,
        //         url: '/lookupatenant',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/manageExistingTenant/lookUpaTenant.html',
        //                 controller: 'lookUpATenantCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.notatepaymentormanagetenant', {
        //         cache: false,
        //         url: '/notatepaymentormanagetenant',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/notatePayment/notatePaymentOrManageTenant.html',
        //                 controller: 'notatePaymentTenantCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.buildinglistnotatepayment', {
        //         cache: false,
        //         url: '/buildinglistnotatepayment',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/notatePayment/buildingListNotatePayment.html',
        //                 controller: 'buildingListNotateCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.listoftenantinbuilding', {
        //         cache: false,
        //         url: '/listoftenantinbuilding',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/notatePayment/listOfTenantInBuilding.html',
        //                 controller: 'listOfTenantInbuildingCtrl'
        //             }
        //         }
        //     })
        //      .state('landlordapp.addbuildingnotate', {
        //         cache: false,
        //         url: '/addbuildingnotate',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/notatePayment/addBuilding.html',
        //                 controller: 'addBuildingNotateCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.tenantUnderBuilding', {
        //         cache: false,
        //         url: '/tenantUnderBuilding',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/TenantList/tenantUnderBuilding.html',
        //                 controller: 'tenantUnderBuildingCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.tenantreview', {
        //         cache: false,
        //         url: '/tenantreview',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/tenantRate/reviewTenant.html',
        //                 controller: 'reviewTenantCtrl'
        //             }
        //         }
        //     })

        // .state('landlordapp.tenantrentinfo', {
        //         cache: false,
        //         url: '/tenantrentinfo',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/tenantRate/rentInfo.html',
        //                 controller: 'rentInfoCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.tenantleavenote', {
        //         cache: false,
        //         url: '/tenantleavenote',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/tenantRate/leaveNote.html',
        //                 controller: 'leaveNoteCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.tenantreviewnote', {
        //         cache: false,
        //         url: '/tenantreviewnote',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/tenantRate/reviewNote.html',
        //                 controller: 'reviewNoteCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.ratetenant', {
        //         cache: false,
        //         url: '/ratetenant',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/tenantRate/rateTenant.html',
        //                 controller: 'rateTenantCtrl'
        //             }
        //         }
        //     })

        // .state('landlordapp.viewTenant', {
        //     cache: false,
        //     url: '/viewTenant',
        //     views: {
        //         'landlordMenuContent': {
        //             templateUrl: 'templates/landlordPart/TenantList/viewTenant.html',
        //             controller: 'viewTenantCtrl'
        //         }
        //     }
        // })

        // .state('landlordapp.checkTenant', {
        //         cache: false,
        //         url: '/checkTenant',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/TenantCheck/checkTenant.html',
        //                 controller: 'checkTenantCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.tenantFullProfile', {
        //         cache: false,
        //         url: '/tenantFullProfile',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/TenantCheck/tenantFullProfile.html',
        //                 controller: 'tenantFullProfileCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.tenantcompleteprofile', {
        //         cache: false,
        //         url: '/tenantcompleteprofile',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/TenantCheck/tenantCompleteProfile.html',
        //                 controller: 'tenantCompleteProfileCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.tenantcriminalrecord', {
        //         cache: false,
        //         url: '/tenantcriminalrecord',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/criminalReportandRecord/criminalRecord.html',
        //                 controller: 'criminalRecordCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.tenantcreditreport', {
        //         cache: false,
        //         url: '/tenantcreditreport',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/criminalReportandRecord/creditReport.html',
        //                 controller: 'creditReportCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.tenantnotfound', {
        //         cache: false,
        //         url: '/tenantnotfound',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/TenantCheck/tenantNotFound.html',
        //                 controller: 'tenantNotFoundCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.confirmtenantdetail', {
        //         cache: false,
        //         url: '/confirmtenantdetail',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/TenantCheck/confirmTenantDetail.html',
        //                 controller: 'confirmTenantDetailCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.addtenant', {
        //         cache: false,
        //         url: '/addtenant',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/TenantAdd/addTenant.html',
        //                 controller: 'addTenantCtrl'
        //             }
        //         }
        //     })

        // .state('landlordapp.viewlandlordprofile', {
        //         cache: false,
        //         url: '/viewlandlordprofile',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/menu/viewLandlordProfile.html',
        //                 controller: 'viewLandlordProfileCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.editlandlordprofile', {
        //         cache: false,
        //         url: '/editlandlordprofile',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/menu/editLandlordProfile.html',
        //                 controller: 'editProfileCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.changePassword', {
        //         cache: false,
        //         url: '/changePassword',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/changePassword/changePassword.html',
        //                 controller: 'changePasswordCtrl'
        //             }
        //         }
        //     })


        // .state('landlordapp.landLordHomeLanding', {
        //     cache: false,
        //     url: '/landLordhome',
        //     views: {
        //         'landlordMenuContent': {
        //             templateUrl: 'templates/landlordPart/LandLordHome/landLordHomeLanding.html',
        //             controller: 'landLordHomeLandingCtrl'
        //         }
        //     }
        // })

        // .state('landlordapp.landLordrateTenantLanding', {
        //         cache: false,
        //         url: '/landLordrateTenantLanding',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/tenantRate/rateTenantLanding.html',
        //                 controller: 'rateTenantLandingCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.rateNewTenant', {
        //         cache: false,
        //         url: '/rateNewTenant',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/tenantRate/rateNewTenant.html',
        //                 controller: 'rateNewTenantCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.rateTenantCheck', {
        //         cache: false,
        //         url: '/rateTenantCheck',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/tenantRate/rateTenantCheck.html',
        //                 controller: 'rateTenantCheckCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.reRateNewTenant', {
        //         cache: false,
        //         url: '/reRateNewTenant',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/tenantRate/reEnterTenant.html',
        //                 controller: 'reRateNewTenantCtrl'
        //             }
        //         }
        //     })

        // .state('landlordapp.giveThumbsUpDown', {
        //         cache: false,
        //         url: '/giveThumbsUpDown',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/tenantRate/rateTenantGiveThumbsUpDown.html',
        //                 controller: 'ratetenantThumbsUpDownCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.rateTenantReview', {
        //         cache: false,
        //         url: '/rateTenantReview',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/tenantRate/rateTenantReviews.html',
        //                 controller: 'ratetenantReviewCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.suggestCategory', {
        //         cache: false,
        //         url: '/suggestCategory',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/tenantRate/suggestCategory.html',
        //                 controller: 'suggestCategoryCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.rateTenantThankyou', {
        //         cache: false,
        //         url: '/rateTenantThankyou',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/tenantRate/rateTenantThankyou.html',
        //                 controller: 'rateTenantThankyouCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.reviewnewtenant', {
        //         cache: false,
        //         url: '/reviewnewtenant',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/TenantAdd/reviewNewTenant.html',
        //                 controller: 'reviewnewtenantCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.reviewnewtenantcontinue', {
        //         cache: false,
        //         url: '/reviewnewtenantcontinue',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/TenantAdd/reviewNewTenantContinue.html',
        //                 controller: 'reviewnewtenantContinueCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.addtenantandremoveexisttenant', {
        //         cache: false,
        //         url: '/addtenantandremoveexisttenant',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/TenantAdd/addTenantAndRemoveExistTenant.html',
        //                 controller: 'addtenantandremoveexisttenantCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.listoftenantunitforremove', {
        //         cache: false,
        //         url: '/listoftenantunitforremove',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/removeTenantFlow/listofTenantUnitForRemove.html',
        //                 controller: 'listOfTenantWithUnitForRemoveCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.enterremoveddatefortenant', {
        //         cache: false,
        //         url: '/enterremoveddatefortenant',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/removeTenantFlow/enterRemovedDate.html',
        //                 controller: 'enterremovedateCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.saveanddisplay', {
        //         cache: false,
        //         url: '/saveanddisplay',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/removeTenantFlow/saveAndDisplay.html',
        //                 controller: 'saveanddisplayCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.rentpaymentdatelandingview', {
        //         cache: false,
        //         url: '/rentpaymentdatelandingview',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/notatePaymentDateAndNotes/rentPaymentDateLandingView.html',
        //                 controller: 'rentPaymentDateNoteLandingCtrl'
        //             }
        //         }
        //     })
        //     .state('landlordapp.addrentpaymentdatenote', {
        //         cache: false,
        //         url: '/addrentpaymentdatenote',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/notatePaymentDateAndNotes/addRentPaymentDateAndNote.html',
        //                 controller: 'addRentPaymentDateAndNoteCtrl'
        //             }
        //         }
        //     })
        //      .state('landlordapp.editrentpaymentdatenote', {
        //         cache: false,
        //         url: '/editrentpaymentdatenote',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/notatePaymentDateAndNotes/editRentPaymentDateAndNote.html',
        //                 controller: 'editRentPaymentDateAndNoteCtrl'
        //             }
        //         }
        //     })
        //      .state('landlordapp.listofpaymentdatenote', {
        //         cache: false,
        //         url: '/listofpaymentdatenote',
        //         views: {
        //             'landlordMenuContent': {
        //                 templateUrl: 'templates/landlordPart/notatePaymentDateAndNotes/listOfPaymentDateAndNotes.html',
        //                 controller: 'listOfPaymentDateAndNotesCtrl'
        //             }
        //         }
        //     })
        $urlRouterProvider.otherwise('/landing/landingView');
    });