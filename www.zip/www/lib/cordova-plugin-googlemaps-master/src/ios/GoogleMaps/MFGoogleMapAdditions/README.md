# MFGoogleMapAdditions

A couple of helpful categories for the Google Maps SDK.


## Installation

Simply add the `GMSCoordinateBounds+Geometry.h` to your project


Enjoy.
