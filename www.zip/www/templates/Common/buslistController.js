angular.module('starter.controllers')
    .controller('buslistctrl', function($scope, $state, $localStorage, $ionicHistory) {
        //ionicMaterialInk.displayEffect();

        $scope.$on('$ionicView.beforeEnter', function(event, viewData) {


           

            
        });
    });